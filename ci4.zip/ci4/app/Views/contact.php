<?= $this->include('template/header_contact'); ?>
<h1><?= $title; ?></h1>
<hr>
<p><?= $content; ?></p>
<?= $this->include('template/footer_contact'); ?>