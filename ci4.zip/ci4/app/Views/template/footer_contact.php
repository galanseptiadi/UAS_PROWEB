<!-- servise -->
    <section class="service">
        <div class="container">
            <h3 align="center">CONTACT INFO</h3><br>
            <div class="row">
                 <div>
                    <h4 align="center">Email: denniluqmantoro@gmail.com</h4>
                </div>
                <div class="col-10">
                    <h4 align="center">Hp: 081585614171</h4>
                </div>
            </div>
        <section id="kontak">
            <div classl="login">
                <input type="text" placeholder="Your Name" class="input">
                <input type="text" placeholder="Your Email Address" class="input">
            </div>

            <div class="subject">
                <input type="text" placeholder="Subject" class="input">
            </div>

            <div class="msg">
                <textarea cols="35" row="10" class="area" placeholder="Your Message" class="Input"></textarea>
            </div>

            <button type="submit"> Send </button>
            
        </section>
        <footer>
            <p>&copy; 2021 - Universitas Pelita Bangsa</p>
        </footer>
        </section>
</body>
</html>