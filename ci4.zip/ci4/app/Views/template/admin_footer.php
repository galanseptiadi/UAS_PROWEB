		<footer>
			<p>&copy; Galan Septiadi - 312010053 - 2022 - Universitas Pelita Bangsa</p>
		</footer>
	</div>
</body>
</html>